/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package e.commerce;
import java.util.Scanner;
public class ECommerce {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        Product electronicProduct = new ElectronicProduct(1, "smartphone", (float) 599.9, "Samsung", 1);
        Product clothingProduct = new ClothingBrand(2, "T-shirt", (float)19.99, "Medium", "Cotton");
        Product bookProduct = new BookProduct(3, "OOP", (float) 39.99, "O'Reilly", "X Publications");
         System.out.print("Enter your customer ID: ");
        int customerId = input.nextInt();
        input.nextLine();
        System.out.print("Enter your name: ");
        String customerName = input.nextLine();
        System.out.print("Enter your address: ");
        String customerAddress = input.nextLine();
        Customer customer = new Customer(customerId, customerName, customerAddress);
        System.out.print("How many products do you want to order? ");
        int numProducts = input.nextInt();
        input.nextLine();
         Cart cart = new Cart(customer.getCostumerId(), numProducts);
         for (int i = 0; i < numProducts; i++) {
            System.out.println("Product " + (i + 1) + ":");
            System.out.print("Enter the product ID: ");
            int productId = input.nextInt();
            input.nextLine(); // consume newline character
            System.out.print("Enter the product name: ");
            String productName = input.nextLine();
            System.out.print("Enter the product price: ");
            float productPrice = input.nextFloat();
            input.nextLine(); // consume newline character
            Product product = new Product(productId, productName, productPrice);
            cart.addProduct(product, i);
        }

        // 6. Place the order
        System.out.print("Do you want to place an order? (y/n) ");
        String orderAnswer = input.nextLine();
        if (orderAnswer.equalsIgnoreCase("y")) {
            cart.placeOrder(customer.getCostumerId());
        } else {
            System.out.println("Order cancelled.");
        }
    }
}
          
        


 
