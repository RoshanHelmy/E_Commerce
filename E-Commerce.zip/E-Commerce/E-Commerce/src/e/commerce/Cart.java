/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package e.commerce;

public class Cart {
    int costumerId;
    int nProducts;
    Product [] products;
    
    public Cart(int customerId, int nProducts) {
        this.costumerId = Math.abs(customerId);
        this.nProducts = Math.abs(nProducts);
        this.products = new Product[nProducts];
    }


    public Cart(int costumerId, int nProducts, Product[] products) {
        this.costumerId = Math.abs(costumerId);
        this.nProducts = 0;
        this.products = new Product[nProducts];
    }

    public void setCostumerId(int costumerId) {
        this.costumerId = costumerId;
    }

    public void setnProducts(int nProducts) {
        this.nProducts = nProducts;
    }

    public void setProducts(Product[] products) {
        this.products = products;
    }

    public int getCostumerId() {
        return costumerId;
    }

    public int getnProducts() {
        return nProducts;
    }

    public Product[] getProducts() {
        return products;
    }
    public void addProduct(Product p){
        if (nProducts == products.length){
            System.out.println("Cart is FULL!");
            return;
        }
         products[nProducts] = p;
         nProducts++;
    }
    
      public void addProduct(Product product, int index) {
        this.products[index] = product;
    }
      
      
    public void removeProduct (int productId){
       for (int i=0; i< nProducts; i++){
           if(products[i].getProductId()== productId){
            System.arraycopy(products, i + 1, products, i, nProducts - i - 1);
            return;
           }
       } 
        System.out.println("Product is not found in Cart");
    }
     public float calculatePrice() {
    float totalPrice = 0;
    for (Product product : products) {
      totalPrice += product.getPrice();
    }
    return totalPrice; 
}
     public Order placeOrder(int customerId) {
    if (nProducts == 0) {
      System.out.println("Cart is empty! Cannot place order.");
      return null;
}
    int orderId = 1; 
    Order order = new Order(customerId, orderId, products, calculatePrice());
    nProducts = 0;
    products = new Product[nProducts]; 
    System.out.println("Order placed successfully!");
    return order;
  }
}
