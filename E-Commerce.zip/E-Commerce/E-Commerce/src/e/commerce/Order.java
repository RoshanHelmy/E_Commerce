/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package e.commerce;

/**
 *
 * @author user
 */
public class Order {
    int costumerId;
    int orderId;
    Product [] products;
    float totalPrice;

    public Order(int costumerId, int orderId, Product[] products, float totalPrice) {
        this.costumerId = Math.abs(costumerId);
        this.orderId = Math.abs(orderId);
        this.products = products;
        this.totalPrice = Math.abs(totalPrice);
    }

     public void printOrderInfo() {
    System.out.println("Order ID: " + orderId);
    System.out.println("Customer ID: " + costumerId);
    System.out.println("Products:");
    for (Product product : products) {
      System.out.println("  - " + product.getName());
    }
    System.out.println("Total Price: $" + totalPrice);
  }
}
