/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package e.commerce;

public class Cart {
 private int customerId;
 private int nProducts;
 private Product[] products;
 private int orderId = 1; // Counter for order ID

public Cart(int customerId, int nProducts) {
this.customerId = Math.abs(customerId);
this.nProducts = Math.abs(nProducts);
this.products = new Product[nProducts];
}

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public void setnProducts(int nProducts) {
        this.nProducts = nProducts;
    }

    public void setProducts(Product[] products) {
        this.products = products;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public int getnProducts() {
        return nProducts;
    }

    public Product[] getProducts() {
        return products;
    }

    public int getOrderId() {
        return orderId;
    }

public void addProduct(Product product) {
for (int i = 0; i < nProducts; i++) {
if (products[i] == null) {
products[i] = product;
return;
}
}
System.out.println("Cart is full. Cannot add more products.");
}

public float calculatePrice() {
float totalPrice = 0.0f;
for (Product product : products) {
if (product != null) {
totalPrice += product.getPrice();
}
}
return totalPrice;
}

public void placeOrder(Customer customer) {
float totalPrice = calculatePrice();
Order order = new Order(orderId++, customer.getCustomerId(), this.nProducts, this.products, totalPrice);
order.printOrderInfo(customer);
}
}
    
   
  

