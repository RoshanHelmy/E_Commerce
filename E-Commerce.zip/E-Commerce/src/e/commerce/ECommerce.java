/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package e.commerce;
import java.util.Scanner;
public class ECommerce {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
ElectronicProduct smartphone = new ElectronicProduct(1, "Smartphone", 599.99f, "Samsung", 1);
ClothingBrand tShirt = new ClothingBrand(2, "T-Shirt", 19.99f, "Medium", "Cotton");
BookProduct oop = new BookProduct(3, "OOP", 39.99f, "O'Reilly", "X Publications");

Scanner scanner = new Scanner(System.in);
System.out.println("Welcome to the E-Commerce System!");
System.out.print("Please enter your id: ");
int customerId = scanner.nextInt();
scanner.nextLine(); 
System.out.print("Please enter your name: ");
String name = scanner.nextLine();
System.out.print("Please enter your address: ");
String address = scanner.nextLine();
Customer customer = new Customer(customerId, name, address);


System.out.print("How many products do you want to add to your cart? ");
int nProducts = scanner.nextInt();
scanner.nextLine(); 
Cart cart = new Cart(customer.getCustomerId(), nProducts);


for (int i = 0; i < nProducts; i++) {
System.out.println("Which product would you like to add? 1- Smartphone 2- T-Shirt 3- OOP");
int choice = scanner.nextInt();
scanner.nextLine(); 
switch (choice) {
case 1:
cart.addProduct(smartphone);
break;
case 2:
cart.addProduct(tShirt);
break;
case 3:
cart.addProduct(oop);
break;
default:
System.out.println("Invalid choice. Skipping this product.");
break;
}
}
System.out.printf("Your total is $%.5f. Would you like to place the order? 1- Yes 2- No%n", cart.calculatePrice());
int orderChoice = scanner.nextInt();
scanner.nextLine(); 
if (orderChoice == 1) {
cart.placeOrder(customer);
} else {
System.out.println("Order canceled.");
}
}
}
    



 
