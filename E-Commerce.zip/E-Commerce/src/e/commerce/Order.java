/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package e.commerce;

/**
 *
 * @author user
 */
public class Order {
private int orderId;
private int customerId;
private Product[] products;
private float totalPrice;

public Order(int orderId, int customerId, int nProducts, Product[] products, float totalPrice) {
this.orderId = orderId;
this.customerId = customerId;
this.products = products;
this.totalPrice = totalPrice;
}

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public void setProducts(Product[] products) {
        this.products = products;
    }

    public void setTotalPrice(float totalPrice) {
        this.totalPrice = totalPrice;
    }

    public int getOrderId() {
        return orderId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public Product[] getProducts() {
        return products;
    }

    public float getTotalPrice() {
        return totalPrice;
    }

public void printOrderInfo(Customer customer) {
System.out.println("Here's your order's summary:");
System.out.println("Order ID: " + this.orderId);
System.out.println("Customer ID: " + this.customerId);
System.out.println("Products:");
for (Product product : this.products) {
if (product != null) {
System.out.println(product.getName() + " $" + product.getPrice());
}
}
System.out.printf("Total Price: $%.2f%n", this.totalPrice);
}
}

